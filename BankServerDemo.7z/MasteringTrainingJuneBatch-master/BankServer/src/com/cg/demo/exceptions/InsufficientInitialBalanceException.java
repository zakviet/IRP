package com.cg.demo.exceptions;

public class InsufficientInitialBalanceException extends Exception {

}
